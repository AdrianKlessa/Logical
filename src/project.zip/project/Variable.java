package project;

public class Variable extends Item{

	String name;
	boolean value;
	public boolean evaluate() {
		return value;
	}
}
