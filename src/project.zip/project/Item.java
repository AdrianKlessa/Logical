package project;

public abstract class Item{
	Item left;
	Item right;
	
	public abstract boolean evaluate();
	
}
