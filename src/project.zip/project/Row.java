package project;

import java.util.ArrayList;

public class Row {

	ArrayList<Variable> variableList = new ArrayList<Variable>();
	boolean evaluation = false;
	
}
