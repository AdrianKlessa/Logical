package project;

public abstract class Function extends Item{
	
	public abstract boolean evaluate();
	
	
}
